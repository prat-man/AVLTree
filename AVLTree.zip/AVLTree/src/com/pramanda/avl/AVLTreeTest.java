package com.pramanda.avl;

import java.util.List;

public class AVLTreeTest
{
	public static void main(String[] args) {
		AVLTree<Integer> tree = new AVLTree<>();
		
		tree.insert(4);
		print(tree);
		
		tree.insert(5);
		print(tree);
		
		tree.insert(2);
		print(tree);
		
		tree.insert(3);
		print(tree);
		
		tree.insert(1);
		print(tree);
	}
	
	public static void print(AVLTree<Integer> tree)
	{
		List<Integer> list = tree.inOrder();
		
		for (Integer i : list) {
			System.out.print(i + " ");
		}
		
		System.out.println();
	}
}

package com.pramanda.avl;

import java.util.ArrayList;
import java.util.List;

public class AVLTree<T extends Comparable<T>>
{
	/** The root node of the AVL tree */
	private Node<T> root;
	
	/**
	 * Non-parameterized constructor
	 */
	public AVLTree() {
		this.root = null;
	}
	
	/**
	 * Insert value into tree
	 * 
	 * @param value
	 */
	public void insert(T value) {
		Node<T> node = new Node<>(value);
		
		if (root == null) {
			root = node;
		}
		else {
			Node<T> currentNode = root;
			
			while (true) {
				if (node.getValue().compareTo(currentNode.getValue()) < 0) {
					if (currentNode.getLeftChild() != null) {
						currentNode = currentNode.getLeftChild();
					}
					else {
						currentNode.setLeftChild(node);
						break;
					}
				}
				else {
					if (currentNode.getRightChild() != null) {
						currentNode = currentNode.getRightChild();
					}
					else {
						currentNode.setRightChild(node);
						break;
					}
				}
			}
			
			balanceTree(currentNode);
		}
	}

	private void balanceTree(Node<T> node) {
		Node<T> currentNode = node;
		
		while (currentNode.getParent() != null) {
			int balance = currentNode.getBalanceFactor();
			int leftBalance = (currentNode.getLeftChild() != null) ? currentNode.getLeftChild().getBalanceFactor() : 0;
			int rightBalance = (currentNode.getRightChild() != null) ? currentNode.getRightChild().getBalanceFactor() : 0;
			
			if (balance < -1) {
				if (rightBalance < 0) {
					// Left Left Rotation
					currentNode = this.leftRotation(currentNode);
				}
				else if (rightBalance > 0) {
					// Right Left Rotation
					this.rightRotation(currentNode.getRightChild());
					currentNode = this.leftRotation(currentNode);
				}
			}
			else if (balance > 1) {
				if (leftBalance > 0) {
					// Right Right Rotation
					currentNode = this.rightRotation(currentNode);
				}
				else if (leftBalance < 0) {
					// Left Right Rotation
					this.leftRotation(currentNode.getLeftChild());
					currentNode = this.rightRotation(currentNode);
				}
			}
			
			// traverse up to parent
			currentNode = currentNode.getParent();
		}
	}
	
	private Node<T> leftRotation(Node<T> node) {
		// pivot node
		Node<T> pivot = node.getRightChild();
		
		// set pivot as child of parent
		if (node.getParent() != null) {
			if (node.getParent().getLeftChild() == node) {
				node.getParent().setLeftChild(pivot);
			}
			else if (node.getParent().getRightChild() == node) {
				node.getParent().setRightChild(pivot);
			}
		}
		
		// perform left rotation
		node.setRightChild(pivot.getLeftChild());
		
		pivot.setLeftChild(node);
		
		return pivot;
	}
	
	private Node<T> rightRotation(Node<T> node) {
		// pivot node
		Node<T> pivot = node.getLeftChild();
		
		// set pivot as child of parent
		if (node.getParent() != null) {
			if (node.getParent().getLeftChild() == node) {
				node.getParent().setLeftChild(pivot);
			}
			else if (node.getParent().getRightChild() == node) {
				node.getParent().setRightChild(pivot);
			}
		}
		
		// perform right rotation
		node.setLeftChild(pivot.getRightChild());
		
		pivot.setRightChild(node);
		
		return pivot;
	}
	
	public List<T> inOrder() {
		List<T> inOrder = new ArrayList<>();
		
		Node<T> currentNode = root;
		
		while (currentNode != null) {
			if (currentNode.getLeftChild() != null) {
				// traverse left sub-tree
				currentNode = currentNode.getLeftChild();
			}
			else if (currentNode.getRightChild() != null) {
				// traverse right sub-tree
				inOrder.add(currentNode.getValue());
				currentNode = currentNode.getRightChild();
			}
			else {
				// logic: keep traversing up until a right sub-tree is encountered or tree is fully traversed
				
				// leaf node, traverse up
				inOrder.add(currentNode.getValue());
				
				if (currentNode.getParent() != null && currentNode.getParent().getLeftChild() == currentNode) {
					// left sub-tree
					while (currentNode != null && currentNode.getRightChild() == null) {
						currentNode = currentNode.getParent();
						inOrder.add(currentNode.getValue());
					}
					
					if (currentNode != null) {
						inOrder.add(currentNode.getValue());
						currentNode = currentNode.getRightChild();
					}
				}
				else {
					// right sub-tree
					Node<T> childNode = currentNode;
					currentNode = currentNode.getParent();
					
					while (currentNode != null && currentNode.getRightChild() == childNode) {
						childNode = currentNode;
						currentNode = currentNode.getParent();
					}
					
					if (currentNode != null) {
						inOrder.add(currentNode.getValue());
						currentNode = currentNode.getRightChild();
					}
				}
			}
		}
		
		return inOrder;
	}
}

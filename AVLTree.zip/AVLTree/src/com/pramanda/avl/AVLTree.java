package com.pramanda.avl;

public class AVLTree<T extends Comparable<T>>
{
	/** The root node of the AVL tree */
	private Node<T> root;
	
	/**
	 * Non-parameterized constructor
	 */
	public AVLTree() {
		this.root = null;
	}
	
	/**
	 * Insert value into tree
	 * 
	 * @param value
	 */
	public void insert(T value) {
		Node<T> node = new Node<>(value);
		
		if (root == null) {
			root = node;
		}
		else {
			Node<T> currentNode = root;
			
			while (currentNode.getLeftChild() != null || currentNode.getRightChild() != null) {
				if (node.getValue().compareTo(currentNode.getValue()) < 0) {
					if (currentNode.getLeftChild() != null) {
						currentNode = currentNode.getLeftChild();
					}
					else {
						currentNode.setLeftChild(node);
					}
				}
				else {
					if (currentNode.getRightChild() != null) {
						currentNode = currentNode.getRightChild();
					}
					else {
						currentNode.setRightChild(node);
					}
				}
			}
			
			balanceTree();
		}
	}

	private void balanceTree() {
		// TODO Auto-generated method stub
	}
}

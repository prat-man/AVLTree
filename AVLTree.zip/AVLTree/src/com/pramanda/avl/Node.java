package com.pramanda.avl;

public final class Node<T extends Comparable<T>>
{
	/** The parent node */
	private Node<T> parent;
	
	/** The left child of the node */
	private Node<T> leftChild;
	
	/** The right child of the node */
	private Node<T> rightChild;
	
	/** The value stored in the node */
	private T value;
	
	/** Height of the subtree */
	private Integer height;
	
	/**
	 * Non-parameterized constructor
	 */
	public Node() {
		this(null);
	}
	
	/**
	 * Parameterized constructor
	 * 
	 * @param value the value to set
	 */
	public Node(T value) {
		super();
		this.value = value;
		this.height = 0;
	}
	
	/**
	 * @return the parent
	 */
	public Node<T> getParent() {
		return parent;
	}

	/**
	 * @param parent the parent to set
	 */
	public void setParent(Node<T> parent) {
		this.parent = parent;
	}

	/**
	 * @return the leftChild
	 */
	public Node<T> getLeftChild() {
		return leftChild;
	}

	/**
	 * @param leftChild the leftChild to set
	 */
	public void setLeftChild(Node<T> leftChild) {
		this.leftChild = leftChild;
		if (this.leftChild != null) this.leftChild.parent = this;
		this.recomputeHeight();
	}

	/**
	 * @return the rightChild
	 */
	public Node<T> getRightChild() {
		return rightChild;
	}

	/**
	 * @param rightChild the rightChild to set
	 */
	public void setRightChild(Node<T> rightChild) {
		this.rightChild = rightChild;
		if (this.rightChild != null) this.rightChild.parent = this;
		this.recomputeHeight();
	}

	/**
	 * @return the value
	 */
	public T getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(T value) {
		this.value = value;
	}
	
	/**
	 * @return the height
	 */
	public Integer getHeight() {
		return height;
	}
	
	/**
	 * @return the balance factor
	 */
	public Integer getBalanceFactor() {
		if (this.leftChild == null && this.rightChild == null) {
			return 0;
		}
		else if (this.leftChild == null) {
			return - this.rightChild.height;
		}
		else if (this.rightChild == null) {
			return this.leftChild.height;
		}
		else {
			return this.leftChild.height - this.rightChild.height;
		}
	}
	
	/**
	 * Method to recompute height of this node
	 */
	private void recomputeHeight()
	{
		if (this.leftChild == null && this.rightChild == null) {
			this.height = 0;
		}
		else if (this.leftChild == null) {
			this.height = this.rightChild.height + 1;
		}
		else if (this.rightChild == null) {
			this.height = this.leftChild.height + 1;
		}
		else {
			this.height = Math.max(this.leftChild.height, this.rightChild.height) + 1;
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Node [parent=" + parent + ", leftChild=" + leftChild + ", rightChild=" + rightChild + ", value=" + value
				+ "]";
	}
}

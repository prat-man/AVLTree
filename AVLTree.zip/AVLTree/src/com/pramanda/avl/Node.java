package com.pramanda.avl;

public class Node<T extends Comparable<T>>
{
	/** The left child of the node */
	private Node<T> leftChild;
	
	/** The right child of the node */
	private Node<T> rightChild;
	
	/** The value stored in the node */
	private T value;
	
	/**
	 * Non-parameterized constructor
	 */
	public Node() {}
	
	/**
	 * Parameterized constructor
	 * 
	 * @param value the value to set
	 */
	public Node(T value) {
		super();
		this.value = value;
	}

	/**
	 * @return the leftChild
	 */
	public Node<T> getLeftChild() {
		return leftChild;
	}

	/**
	 * @param leftChild the leftChild to set
	 */
	public void setLeftChild(Node<T> leftChild) {
		this.leftChild = leftChild;
	}

	/**
	 * @return the rightChild
	 */
	public Node<T> getRightChild() {
		return rightChild;
	}

	/**
	 * @param rightChild the rightChild to set
	 */
	public void setRightChild(Node<T> rightChild) {
		this.rightChild = rightChild;
	}

	/**
	 * @return the value
	 */
	public T getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(T value) {
		this.value = value;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Node [leftChild=" + leftChild + ", rightChild=" + rightChild + ", value=" + value + "]";
	}
}
